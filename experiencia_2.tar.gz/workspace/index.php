<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Experiencia 2</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/full-width-pics.css" rel="stylesheet">
    
    <?php include 'validate.php'; ?>
 
  </head>

  <body>

    <!-- Navigation -->

    <!-- Header - set the background image for the header in the line below -->

    <!-- Content section -->
    <section class="py-5">
      <form class="form-horizontal" role="form" method="post" action="index.php">
      	<div class="form-group">
      		<label for="name" class="col-sm-2 control-label">Nombre</label>
      		<div class="col-sm-10">
      			<input type="text" class="form-control" id="name" name="name" placeholder="Ingrese nombre" value="<?php echo htmlspecialchars($_POST['name']); ?>">
      			<?php echo "<p class='text-danger'>$errName</p>";?>
      		</div>
      	</div>
      	
      	<div class="form-group">
      		<label for="name" class="col-sm-2 control-label">Apellido</label>
      		<div class="col-sm-10">
      			<input type="text" class="form-control" id="lastname" name="lastname" placeholder="Ingrese apellido" value="<?php echo htmlspecialchars($_POST['name']); ?>">
      			<?php echo "<p class='text-danger'>$errLast</p>";?>
      		</div>
      	</div>
      	
      	<div class="form-group">
      		<label for="name" class="col-sm-2 control-label">Fecha de nacimiento</label>
      		<div class="col-sm-10">
      			<input type="text" class="form-control" id="date" name="date" placeholder="Ingrese su fecha de nacimiento" value="<?php echo htmlspecialchars($_POST['name']); ?>">
      			<?php echo "<p class='text-danger'>$errDate</p>";?>
      		</div>
      	</div>
      	
      	<div class="form-group">
      		<label for="name" class="col-sm-2 control-label">Sexo</label>
      		<div class="col-sm-10">
            <div class="radio">
              <label><input type="radio" name="sex" value="h"> Hombre</label>
            </div>
            <div class="radio">
              <label><input type="radio" name="sex" value="m"> Mujer</label>
            </div>
            <div class="radio">
              <label><input type="radio" name="sex" value="o"> Otro</label>
            </div>
      			<?php echo "<p class='text-danger'>$errSex</p>";?>
      		</div>
      	</div>
      	
      	<div class="form-group">
      		<label for="name" class="col-sm-2 control-label">Región</label>
      		<div class="col-sm-10">
            <div class="form-group">
              <select class="form-control" id="sel1">
                <option name="XV" value="15">XV	 Arica y Parinacota,	Arica</option>
                <option name="I" value="1">I	 Tarapacá,	Iquique</option>
                <option name="II" value="2">II	 Antofagasta,	Antofagasta</option>
                <option name="III" value="3">III	 Atacama,	Copiapó</option>
                <option name="IV" value="4">IV	 Coquimbo,	La Serena</option>
                <option name="V" value="5">V	 Valparaíso,	Valparaíso</option>
                <option name="RM" value="13">RM	 Metropolit,ana	Santiago</option>
                <option name="VI" value="6">VI	 O’Higgins,	Rancagua</option>
                <option name="VII" value="7">VII	 Maule,	Talca</option>
                <option name="VIII" value="8">VIII	 Biobío,	Concepción</option>
                <option name="IX" value="9">IX	 Araucanía,	Temuco</option>
                <option name="XIV" value="14">XIV	 Los Ríos,	Valdivia</option>
                <option name="X" value="10">X	 Los Lagos,	Puerto Montt</option>
                <option name="XI" value="11">XI	 Aysén,	Coyhaique</option>
                <option name="XII" value="12">XII	 Magallanes,	Punta Arenas</option>
              </select>
            </div>
      			<?php echo "<p class='text-danger'>$errRegion</p>";?>
      		</div>
      	</div>  
      	

      	<div class="form-group">
      		<label for="name" class="col-sm-2 control-label">Áreas de interés</label>
      		<div class="col-sm-10">      	
          	<div class="checkbox">
              <label><input type="checkbox" name="Ciencia" value="0"> Ciencia</label>
            </div>
            <div class="checkbox">
              <label><input type="checkbox" name="Música" value="0"> Música</label>
            </div>
            <div class="checkbox">
              <label><input type="checkbox" name="Deportes" value="0"> Deportes</label>
            </div>
            <div class="checkbox">
              <label><input type="checkbox" name="Pintura" value="0"> Pintura rupestre</label>
            </div>
            <div class="checkbox">
              <label><input type="checkbox" name="Videos" value="0"> Videos de gatos</label>
            </div>
      			<?php echo "<p class='text-danger'>$errInterest</p>";?>
      		</div>
      	</div>
      	
      	<div class="form-group">
      		<label for="name" class="col-sm-2 control-label"> Página persona</label>
      		<div class="col-sm-10">
      			<input type="url" class="form-control" id="url" name="url" placeholder="ingrese url" value="<?php echo htmlspecialchars($_POST['url']); ?>">
      			<?php echo "<p class='text-danger'>$errUrl</p>";?>
      		</div>
      	</div>
      	
      	<div class="form-group">
      		<label for="email" class="col-sm-2 control-label">Email</label>
      		<div class="col-sm-10">
      			<input type="email" class="form-control" id="email" name="email" placeholder="ejemplo@domanio.com" value="<?php echo htmlspecialchars($_POST['email']); ?>">
      			<?php echo "<p class='text-danger'>$errEmail</p>";?>
      		</div>
      	</div>

      	<div class="form-group">
      		<label for="human" class="col-sm-2 control-label">Color favorito</label>
      		<div class="col-sm-10">
      		  <input type="color" id="color" name="color" />
      			<?php echo "<p class='text-danger'>$errColor</p>";?>
      		</div>
      	</div>
      	

      	
      	<div class="form-group">
      		<div class="col-sm-10 col-sm-offset-2">
      			<input id="submit" name="submit" type="submit" value="Send" class="btn btn-primary">
      		</div>
      	</div>
      	
      	<div class="form-group">
      		<div class="col-sm-10 col-sm-offset-2">
      			<?php echo $result; ?>	
      		</div>
      	</div>
      </form> 
    </section>

    <!-- Image Section - set the background image for the header in the line below -->

    <!-- Content section -->

    <!-- Footer -->
    <footer class="py-5 bg-inverse">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2017</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  </body>

</html>
