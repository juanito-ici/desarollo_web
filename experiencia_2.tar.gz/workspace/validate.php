<?php
	if (isset($_POST["submit"])) {
		$name = $_POST['name'];
		$lastname = $_POST['lastname'];
		$date = $_POST['date'];
		$sex = $_POST['sex'];
		$region = $_POST['region'];
		$interest = $_POST['interest'];
		$url = $_POST['url'];
		$email = $_POST['email'];
		$color = $_POST['color'];

		$body = "From: $name\n E-Mail: $email\n Message:\n $message";
 
		// Check if name has been entered
		if (!$_POST['name']) {
			$errName = 'Por favor ingrese nombre';
		}
		if (!$_POST['lastname']) {
			$errLast = 'Por favor ingrese apellido';
		}
		if (!$_POST['date']) {
			$errDate = 'Por favor ingrese Fecha de Nacimiento';
		}
		if (!isset($sex)){
			$errSex = 'Por favor ingrese su sexo';
		}
		if (!isset($region)){
			$errRegion = 'Por favor ingrese su region';
		}
		if (!isset($interest)){
			$errInterest = 'Por favor ingrese sus intereses';
		}
		if (!filter_var($url, FILTER_VALIDATE_URL)) {
			$errUrl = 'Por favor ingrese su pagina personal';
		}
		if (!$_POST['email'] || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
			$errEmail = 'Please enter a valid email address';
		}
		//Check if message has been entered
		if (!$_POST['color']) {
			$errColor = 'Por favor ingrese su color';
		}
// If there are no errors, send the email
if (!$errName && !$errLast && !$errDate && !$errSex && !$errRegion && !$errInterest && !$errUrl && !$errEmail && !$errColor) {
		$result='<div class="alert alert-success">formulario enviado completamente</div>';
	}else{ if (!$errName && !$errLast && !$errDate && !$errSex) {
			$result='<div class="alert alert-success">formulario enviado incompleto</div>';
		}
	}
}
?>